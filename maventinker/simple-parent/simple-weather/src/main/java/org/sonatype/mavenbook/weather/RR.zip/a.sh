sed -e 's:package org.sonatype.mavenbook.ch04.weather:package org.sonatype.mavenbook.weather:g' -i *java*
